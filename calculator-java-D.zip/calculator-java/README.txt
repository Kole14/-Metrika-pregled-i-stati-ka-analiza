Nikola Kovac 

LOC: 214 (Calculator and Start)

---------------------------------------------------------------

Ciklomatska složenost: 1 (Calculator::Operations::Operations)
Ciklomatska složenost: 1 (Calculator::Operations::ToString)
Ciklomatska složenost: 1 (Calculator::Run)
Ciklomatska složenost: 12 (Calculator::evaluateExpression)
Ciklomatska složenost: 12 (Calculator::Calculate)

Ciklomatska složenost: 3 (Start::main)

---------------------------------------------------------------

Kognitivna složenost: 2 (Calculator::Operations::Operations)
Kognitivna složenost: 2 (Calculator::Operations::ToString)
Kognitivna složenost: 2 (Calculator::Run)
Kognitivna složenost: 13 (Calculator::evaluateExpression)
Kognitivna složenost: 13 (Calculator::Calculate)

Kognitivna složenost: 4 (Start::main)

--------------------------------------------------------------

Calculkator.java - 1 - Move this file to a named package
Calculkator.java - 4 - Add a private constructor to hide the implicit public one
Calculkator.java - 18 - Rename method \"ToString\" to prevent any misunderstanding/clash with method \"toString\
Calculkator.java - 18 - Rename method name to match the regular expression
Calculkator.java - 24 - Rename method name to match the regular expression
Calculkator.java - 53 - Use enhanced for loop to iterate over the array
Calculkator.java - 55 - Convert to switch
Calculkator.java - 62 - Unnecessary temporary when converting from String
Calculkator.java - 63 - Can be replaced with multicatch clauses catching specific exceptions
Calculkator.java - 70 - Immediately return this expression instad of assigning it to the temporary veriable "textResult"
Calculkator.java - 74 - Rename this method name to match the regular expression
Calculkator.java - 183 - Unnecessary return statement
Calculkator.java - 183 - Remove this redundant jump


Start.java - 1 - Move this return to a named package
Start.java - 6 - Rename this local veriable to match the regular expression
Start.java - 8 - Replace this use of System.out by a logger
Start.java - 19 - Replace this use of System.out by a logger


